package edu.scala.basic.tut1

class Rational(n: Int, d: Int) {
  require(d != 0, "Rational has denom is Zero")

  private val g = gcd(n.abs, d.abs)
  private def gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)

  val numer = n / g
  val denom = d / g

  def this(n: Int) = this(n, 1)
  def this() = this(0, 1)

  def +(that: Rational): Rational = new Rational(this.numer * that.denom + that.numer * this.denom, this.denom * that.denom)
  def +(that: Int): Rational = new Rational(this.numer + that * this.denom, this.denom)

  def *(that: Rational): Rational = new Rational(this.numer * that.numer, this.denom * that.denom)
  def *(that: Int): Rational = new Rational(this.numer * that, this.denom)

  override def toString = if (numer == 0) "0" else if (numer == denom) "1" else if (denom == 1) numer.toString else numer + "/" + denom
}

object Rational {
  def main(agrs: Array[String]) = {
    val ra1 = new Rational(5, 3)
    val ra2 = new Rational(3, 4)
    val ra3 = new Rational()

    val raSum = ra1 + ra2
    val raSum2 = ra1 + 7
    
    val raMul = ra1 * ra2
    val raMul2 = ra1 * 2

    println(ra1)
    println(ra2)
    println(ra3)
    println(raSum)
    println(raSum2)
    println(raMul)
    println(raMul2)
  }
}