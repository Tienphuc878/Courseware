#!/bin/bash
echo "Running Main"
scala -classpath ../bin Main -testlexer 1 5 ../testcases  ../lexersol
